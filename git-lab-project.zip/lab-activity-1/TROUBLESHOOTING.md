# Activity 2 - contact.html missing from GitHub

## 1. Diagnosis
`git status` showed `modified: contact.html`, which means Git already tracks the file
(it was committed earlier), but the new changes were never **staged** with `git add`
and never **committed**. `git push` only sends *commits*, so nothing new reached GitHub.
The skipped step: `git add` (staging) followed by `git commit`.

(If it showed `untracked` instead, the file was never added at all - same fix.)

## 2. Fix
```bash
git status                       # see contact.html as modified / untracked
git add contact.html             # stage the file
git commit -m "Add contact page" # save a snapshot
git push origin main             # upload the commit
```

## 3. Short explanation
Git works in three stages: working directory -> staging area (`git add`) -> repository
(`git commit`) -> GitHub (`git push`). The file existed on the computer, but it was
never staged and committed, so push had nothing to upload. After add + commit + push,
the file appears on GitHub.
