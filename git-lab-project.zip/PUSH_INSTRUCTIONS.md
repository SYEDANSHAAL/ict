# GitHub par push karne ke steps
GitHub par 2 EMPTY repos banao: `lab-activity-1` aur `techtreasure-blog` (README mat add karna).

## Repo 1
cd lab-activity-1
git remote add origin https://github.com/<YOUR-USERNAME>/lab-activity-1.git
git push -u origin main

## Repo 2
cd ../techtreasure-blog
git remote add origin https://github.com/<YOUR-USERNAME>/techtreasure-blog.git
git push -u origin main
git push -u origin feature-navbar

Link hoga: https://github.com/<YOUR-USERNAME>/lab-activity-1 aur .../techtreasure-blog
(Pehle `git config user.name/email` apne naam se set kar lena.)
