# TechTreasure Blog - Design Guide

**Theme:** Cyberpunk neon

## Color palette
| Role | Color | Hex |
|---|---|---|
| Background | Deep midnight | #0a0a14 |
| Primary / headings | Neon cyan | #00fff2 |
| Secondary / subheadings | Neon magenta | #ff2bd6 |
| Links / highlights | Electric yellow | #fcee09 |
| Body text | Soft lavender white | #e6e6ff |

## Typography
- Font: Courier New (monospace) for a hacker/terminal feel.
- H1 large with a neon glow (text-shadow); H2 in magenta; body at 16px with 1.6 line height.

## Layout strategy
- Single centered column, generous padding, dark background for neon contrast.
- Simple navigation bar at the top (added in branch `feature-navbar`) linking Home and Blog.
- Consistent structure on every page: navbar, H1 title, H2 sections, short paragraphs.
